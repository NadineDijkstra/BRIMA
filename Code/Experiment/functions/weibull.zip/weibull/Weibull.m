function y = Weibull(p,x)
%y = Weibull(p,x)
%
%Parameters:  p.b slope
%             p.t threshold yeilding p.a% correct
%             p.a 
%             x   intensity values.

g = (1/3);  %chance performance
e = p.a; %(.5)^(1/3);  %threshold performance ( ~80%)

%here it is.
k = (-log( (1-e)/(1-g)))^(1/p.b);
y = 1- (1-g)*exp(- (k*x/p.t).^p.b);