function [ i, j, k] = find3d( mat )
% Does find in three dimensions
%
%  written by matlab class 2011


vect=mat(:);
ind=find(vect);
[i, j, k]=ind2sub(sz, ind);
